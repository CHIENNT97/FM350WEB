-- 字符串修剪函数，去除前后空格
local function trim(s)
    if s == nil then
        return ""  -- 返回一个空字符串以防止错误
    end
    return s:match("^%s*(.-)%s*$")
end

-- 从文件中读取数据
local function readDataFromFile(dataFile)
    local info = {}
    local file, err = io.open(dataFile, "r")
    
    if not file then
        print("无法打开文件: " .. err)
        return nil
    end

    for line in file:lines() do
        line = trim(line)  -- 去掉前后空白
        if line ~= "" then  -- 只处理非空行
            if line:find("Manufacturer:") then
                info["Manufacturer"] = trim(line:match("Manufacturer: (.+)"))
            elseif line:find("Model:") then
                info["Model"] = trim(line:match("Model: (.+)"))
            elseif line:find("Revision:") then
                info["Revision"] = trim(line:match("Revision: (.+)"))
            elseif line:find("IMEI:") then
                info["IMEI"] = trim(line:match("IMEI: (.+)"))
            elseif line:find("+COPS:") then
                -- 调整匹配逻辑，简化部分
                local operator = line:match('"%s*([^"]+)%s*",%d')
                print("匹配到的运营商: " .. tostring(operator))  -- 输出匹配到的运营商
                info["运营商"] = trim(operator)
            elseif line:find("PCC") then
                   -- 使用模式匹配提取需要的值
                 print("匹配到的行: " .. line)  -- 打印匹配到的行
-- 使用更广泛的模式匹配，匹配所有数字
                local pccData = line:match("PCC:(%d+),(%d+),(%d+)")
                if pccData then
                    -- 提取数字
                    local pccValues = {}
                    for v in line:gmatch("(%d+)") do
                        table.insert(pccValues, v)
                    end

                    -- 检查是否提取到了足够的值
                    if #pccValues >= 3 then
                        -- 提取504990的前四位
                        local fourthValue = string.sub(pccValues[3], 1, 6)
                        local signalStrength = line:match(",(-?%d+)$")

                        -- 存储结果
                        info["频段"] = pccValues[1]  -- 5041
                        info["PCI"] = pccValues[2]   -- 190
                        info["ARFFG"] = fourthValue   -- 5049
                        info["信号"] = signalStrength or "无信号"  -- 处理信号强度

                        -- 输出提取结果
                        print("频段: " .. info["频段"])
                        print("PCI: " .. info["PCI"])
                        print("ARFFG: " .. info["ARFFG"])
                        print("信号: " .. info["信号"])
                    else
                        print("无法提取足够的 PCC 数据！")
                    end
                else
                    print("未能匹配到 PCC 数据！")
                end
            end
        end
    end

    file:close()
    return info
end

-- 从文件中读取数据并解析所需信息
local function initDataFromFile(dataFile)
    local serialPort = ""
    local frequency = ""

    local file, err = io.open(dataFile, "r")
    
    if not file then
        print("无法打开文件: " .. err)
        return nil, nil  -- 返回 nil 如果文件打不开
    end

    for line in file:lines() do
        line = trim(line)  -- 去掉前后空白
        
        if line:find("串口选择:") then
            serialPort = trim(line:match("串口选择: (.+)"))
        elseif line:find("开机锁频:") then
            frequency = trim(line:match("开机锁频: (.+)"))
        end
    end
    
    file:close()
    return serialPort, frequency
end

-- 直接构建 HTML 文件
local function writeDataToHTML(info, outputFile)
    local htmlContent = [[
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>通信模块信息</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: auto;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f8f8f8;
        }
		.button-container {
            text-align: center;
            margin-top: 20px; /* 加大按钮与表格间的间距 */
        }
        button {
            margin: 0 5px; /* 按钮间距 */
            padding: 10px 15px;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3; /* 添加 hover 效果 */
        }
    </style>
	<script>
        function lockFrequency() {
            alert('准备进入锁频段');
            // 在这里可以添加更多逻辑，例如调用API或更新状态
			 window.location.href = 'lock.html';  // 跳转到锁频段页面
        }

        function lockCell() {
            alert('准备进入锁小区');
            // 在这里可以添加更多逻辑，例如调用API或更新状态
			window.location.href = 'lock_cell.html';  // 跳转到锁小区页面
        }
        function scanCell() {
            alert('准备进入扫描小区');
            // 在这里可以添加更多逻辑，例如调用API或更新状态
			window.location.href = 'scan.html';  // 跳转到扫描小区页面
        }
        function advancedMenu() {
            alert('高级菜单按钮被点击!');
            // 在这里可以添加更多逻辑，例如打开新的菜单或窗口
			window.location.href = 'config.html';  // 跳转到扫描小区页面
        }
    </script>
</head>
<body>

<div class="container">
    <h2>通信模块信息</h2>
<table>
]]

    -- 遍历 info 表并生成表格内容
    for key, value in pairs(info) do
        if value then
            htmlContent = htmlContent .. string.format("<tr><th>%s</th><td>%s</td></tr>", key, value)
        end
    end

    htmlContent = htmlContent .. [[
    </table>
	<th>P群专用 FM350GL 交流群：624732427</th>
</div>

</body>
</html>
    <!-- 添加按钮在下方 -->
    <div class="button-container">
        <button onclick="lockFrequency()">锁频段</button>
        <button onclick="lockCell()">锁小区</button>
		<button onclick="scanCell()">扫描小区</button>
        <button onclick="advancedMenu()">高级菜单</button>
    </div>
]]

    -- 写入结果到文件
    local file, err = io.open(outputFile, "w")
    if file then
        file:write(htmlContent)
        file:close()
        print("数据已写入 " .. outputFile)
    else
        print("无法打开输出文件: " .. outputFile .. ". 错误信息: " .. err)
    end
end

-- 主函数
local function main()
    local dataFile = '/root/350/config_data.txt'  -- 更新为您的配置文件路径
    local serialPort, frequency = initDataFromFile(dataFile)

    if serialPort and frequency then
        print("串口选择: " .. serialPort)
        print("开机锁频: " .. frequency)
    else
        print("未能提取有效数据。")
    end
    local dataFile = '/tmp/data.txt'
    local outputFile = '/www/350/index.html'
	--io.popen("comgt -d /dev/ttyUSB0 -s /www/350/comgt/getdata.gcom > /tmp/data.txt") -- 在 Unix/Linux 系统中
	local command = string.format("comgt -d %s -s /www/350/comgt/getdata.gcom > %s", serialPort, dataFile)
	io.popen(command) -- 在 Unix/Linux 系统中
	print("执行代码:" ..command)
    local info = readDataFromFile(dataFile)

    -- 打印读取的数据
    for k, v in pairs(info) do
        print("数据: [" .. k .. "] -> [" .. v .. "]")
    end

    if next(info) then
        writeDataToHTML(info, outputFile)
        print("数据已更新到 HTML 文件.")
    else
        print("未读取到有效数据。请检查 data.txt 文件。")
    end
end

main()
