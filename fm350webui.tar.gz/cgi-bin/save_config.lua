#!/usr/bin/lua

local mymodule = loadfile("/root/cgi-bin/utils.lua")()

-- 设置响应头
print("Content-type: text/html; charset=UTF-8\n")
print() -- 重要，必须有一个空行以结束头部

-- 解析查询字符串函数
local function parse_query(query)
    local params = {}
    for pair in string.gmatch(query, "([^&]+)") do
        local key, value = pair:match("([^=]*)=([^=]*)")
        if key and value then
            -- 解码 '+' 为空间，进行 URL 解码
            value = value:gsub("+", " "):gsub("%%(%x%x)", function(hex) return string.char(tonumber(hex, 16)) end)
            params[key] = value
        end
    end
    return params
end

-- 获取查询字符串
local query_string = os.getenv("QUERY_STRING") or ""
-- 解析查询字符串
local params = parse_query(query_string)
-- 提取 PCI 和频率参数
local imei = params["imei"] or "未提供"
--AT+EGMREXT=1,7," ..imei.. "
-- 检查 IMEI 长度
if imei ~= "未提供" and #imei == 15 then
    local sendimei = 'AT+EGMREXT=1,7,"' .. imei .. '"'
	-- 使用 AT 命令函数
	mymodule.send_at_command(sendimei)
end
 
-- 输出 HTML 格式的结果
print("<html>")
print("<head><title>imei修改</title></head>")
print("<body>")
print("<h1>imei修改结果</h1>")
print("<p>IMEI: " .. imei .. "</p>")
print("</body>")
print("</html>")
