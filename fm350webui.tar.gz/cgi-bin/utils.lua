#!/usr/bin/lua

local mymodule = {}

-- 字符串修剪函数，去除前后空格
local function trim(s)
    if s == nil then
        return ""  -- 返回一个空字符串以防止错误
    end
    return s:match("^%s*(.-)%s*$")
end

-- 从配置文件读取串口选择和开机锁频
local function initDataFromFile(dataFile)
    local serialPort = ""
    local frequency = ""

    local file, err = io.open(dataFile, "r")
    
    if not file then
        print("无法打开文件: " .. err)
        return nil, nil
    end

    for line in file:lines() do
        line = trim(line)
        if line:find("串口选择:") then
            serialPort = trim(line:match("串口选择: (.+)"))
        elseif line:find("开机锁频:") then
            frequency = trim(line:match("开机锁频: (.+)"))
        end
    end
    
    file:close()
    return serialPort, frequency
end

-- 函数：发送 AT 命令
function mymodule.send_at_command(data)
-- 定义chat命令，用 long bracket 来避免复杂的转义
    local output_file = "/tmp/at_command_output.txt"
	local configFile = '/root/350/config_data.txt'  -- 配置文件路径
	local serialPort, configFrequency = initDataFromFile(configFile)
	if serialPort and configFrequency then
    print("串口选择: " .. serialPort)
  --  print("开机锁频: " .. configFrequency)
    else
     response = response .. "<p>Error: 未能提取有效的数据。</p>"
    end
    -- 转义字符
    local escaped_data = data:gsub('"', '\\"'):gsub('%^', '\\^')
    -- 定义 chat 命令
    local command = string.format("chat -v -t 3 -e '' '%s' OK > %s < %s", escaped_data, serialPort, serialPort)
	-- 完整命令，包括输出到文件
	local result = os.execute(command)
	print("发送AT指令：", command)
	print("执行结果：", result)
    output = "OK"
    return output  -- 返回输出
	-- 打印执行结果代码
end

return mymodule