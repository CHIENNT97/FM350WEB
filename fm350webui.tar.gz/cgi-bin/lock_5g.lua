#!/usr/bin/lua

-- 字符串修剪函数，去除前后空格
local function trim(s)
    if s == nil then
        return ""  -- 返回一个空字符串以防止错误
    end
    return s:match("^%s*(.-)%s*$")
end

-- 从配置文件读取串口选择和开机锁频
local function initDataFromFile(dataFile)
    local serialPort = ""
    local frequency = ""

    local file, err = io.open(dataFile, "r")
    
    if not file then
        print("无法打开文件: " .. err)
        return nil, nil
    end

    for line in file:lines() do
        line = trim(line)
        if line:find("串口选择:") then
            serialPort = trim(line:match("串口选择: (.+)"))
        elseif line:find("开机锁频:") then
            frequency = trim(line:match("开机锁频: (.+)"))
        end
    end
    
    file:close()
    return serialPort, frequency
end

-- 设置响应头
print("Content-type: text/html; charset=UTF-8\n")
print() -- 重要，必须有一个空行以结束头部

-- 函数：发送 AT 命令
function send_at_command(data, serialPort)
    local output_file = "/tmp/at_command_output.txt"
    
    -- 转义字符
    local escaped_data = data:gsub('"', '\\"'):gsub('%^', '\\^')
    
    -- 定义 chat 命令
    local command = string.format("chat -v -t 3 -e '' '%s' OK > %s < %s", escaped_data, serialPort, serialPort)
    
    local result = os.execute(command)
    print("发送AT指令：", command)
    print("执行结果：", result)
    
    output = "OK"
    return output  -- 返回输出
end

-- 获取用户输入的频段
local frequency = nil

-- 从 CGI 参数读取输入
local query_string = os.getenv("QUERY_STRING")
if query_string then
    for param in query_string:gmatch("([^&]+)") do
        local key, value = param:match("([^=]+)=([^=]*)")
        if key and value then
            if key == "frequency" then
                frequency = value
            end
        end
    end
end

-- 构建输出结果
local response = "<html><body><h1>Lock 5G Frequency Result</h1>"

local configFile = '/root/350/config_data.txt'  -- 配置文件路径
local serialPort, configFrequency = initDataFromFile(configFile)

if serialPort and configFrequency then
    print("串口选择: " .. serialPort)
   -- print("开机锁频: " .. configFrequency)
else
    response = response .. "<p>Error: 未能提取有效的数据。</p>"
end

if frequency == nil then
    response = response .. "<p>Error: No frequency provided.</p>"
else
    -- 使用表进行映射
    local commands = {
        AUTO = 'AT+GTACT=20',
        ["5G"] = 'AT+GTACT=14',
        ["4G"] = 'AT+GTACT=2',
        N41 = 'AT+GTACT=14,6,6,5041',
        N28 = 'AT+GTACT=14,6,6,5028',
        N1 = 'AT+GTACT=14,6,6,501',
        N78 = 'AT+GTACT=14,6,6,5078',
        N79 = 'AT+GTACT=14,6,6,5079',
    }

    -- 获取与 frequency 对应的命令
    local command = commands[frequency]

    if command then
        -- 发送 AT 命令以锁定频段
        print("构建的 AT 命令: " .. command)
		local RESULT = send_at_command("AT+EMMCHLCK=0",serialPort)
		local output = send_at_command("AT+CFUN=0", serialPort)
        local output = send_at_command(command, serialPort)
		local output = send_at_command("AT+CFUN=1", serialPort)
        -- 判断 AT 命令是否成功
        if output and #output > 0 then
            response = response .. "<p>Successfully locked frequency: " .. frequency .. ".</p>"
            response = response .. "<p>AT Command Output: " .. output .. "</p>"
        else
            response = response .. "<p>Error executing AT command: " .. frequency .. "</p>"
        end
    else
        response = response .. "<p>Error: Invalid frequency provided: " .. frequency .. "</p>"
    end
end

response = response .. '<br><a href="/350/index.html">Go Back</a>'
response = response .. "</body></html>"

-- 输出响应
print(response)
