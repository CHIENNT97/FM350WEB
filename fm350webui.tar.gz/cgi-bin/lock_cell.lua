#!/usr/bin/lua

-- 字符串修剪函数，去除前后空格
local function trim(s)
    if s == nil then
        return ""  -- 返回一个空字符串以防止错误
    end
    return s:match("^%s*(.-)%s*$")
end

-- 从配置文件读取串口选择和开机锁频
local function initDataFromFile(dataFile)
    local serialPort = ""
    local frequency = ""

    local file, err = io.open(dataFile, "r")
    
    if not file then
        print("无法打开文件: " .. err)
        return nil, nil
    end

    for line in file:lines() do
        line = trim(line)
        if line:find("串口选择:") then
            serialPort = trim(line:match("串口选择: (.+)"))
        elseif line:find("开机锁频:") then
            frequency = trim(line:match("开机锁频: (.+)"))
        end
    end
    
    file:close()
    return serialPort, frequency
end

-- 设置响应头
print("Content-type: text/html; charset=UTF-8\n")
print() -- 重要，必须有一个空行以结束头部

-- 函数：发送 AT 命令
function send_at_command(data, serialPort)
    local output_file = "/tmp/at_command_output.txt"
    
    -- 转义字符
    local escaped_data = data:gsub('"', '\\"'):gsub('%^', '\\^')
    
    -- 定义 chat 命令
    local command = string.format("chat -v -t 3 -e '' '%s' OK > %s < %s", escaped_data, serialPort, serialPort)
    
    local result = os.execute(command)
    print("发送AT指令：", command)
    print("执行结果：", result)
    
    output = "OK"
    return output  -- 返回输出
end

-- 解析查询字符串函数
local function parse_query(query)
    local params = {}
    for pair in string.gmatch(query, "([^&]+)") do
        local key, value = pair:match("([^=]*)=([^=]*)")
        if key and value then
            -- 解码 '+' 为空间，进行 URL 解码
            value = value:gsub("+", " "):gsub("%%(%x%x)", function(hex) return string.char(tonumber(hex, 16)) end)
            params[key] = value
        end
    end
    return params
end

-- 获取查询字符串
local query_string = os.getenv("QUERY_STRING") or ""

-- 解析查询字符串
local params = parse_query(query_string)

-- 提取 PCI 和频率参数
local PCI = params["pci"] or "未提供"
local FREQUENCY = params["frequency"] or "未提供"
-- 同时判断两个条件
--AT+CFUN=0 （飞行模式）
--AT+EMMCHLCK=1,11,0,627264,280,3
--AT+CFUN=1   （在线模式）
-- 输出 PCI 和频率的值及其长度
local pci_length = #PCI
local frequency_length = #FREQUENCY

-- 输出 PCI 和频率的值及其长度
print("<p>PCI: " .. PCI .. " (长度: " .. pci_length .. ")</p>")
print("<p>频率: " .. FREQUENCY .. " (长度: " .. frequency_length .. ")</p>")

-- 同时判断两个条件
if pci_length == 3 and frequency_length == 6 then
		-- 构建输出结果
	local response = "<html><body><h1>Lock 5G Frequency Result</h1>"
	local configFile = '/root/350/config_data.txt'  -- 配置文件路径
	local serialPort, configFrequency = initDataFromFile(configFile)
	if serialPort and configFrequency then
    print("串口选择: " .. serialPort)
  --  print("开机锁频: " .. configFrequency)
    else
     response = response .. "<p>Error: 未能提取有效的数据。</p>"
    end
	
    print("<p>PCI 和频率都有效</p>")
	local RESULT =send_at_command("AT+CFUN=0",serialPort)
	RESULT=send_at_command("AT+GTACT=20",serialPort)
	RESULT=send_at_command("AT+EMMCHLCK=0",serialPort)
	RESULT=send_at_command("AT+EMMCHLCK=1,11,0," .. FREQUENCY .. "," .. PCI .. ",3",serialPort)
	RESULT=send_at_command("AT+CFUN=1")	
	print("AT+EMMCHLCK=1,11,0," .. FREQUENCY .. "," .. PCI .. ",3",serialPort)
else
    if pci_length ~= 3 then
        print("<p>PCI 长度无效，应该为3个字符</p>")
    end
    if frequency_length ~= 6 then
        print("<p>频率长度无效，应该为6个字符</p>")
    end
end




-- 这里添加与 FM350 通信的代码
local RESULT = "锁小区成功"  -- 模拟成功返回，实际中应根据执行结果返回相应信息

-- 输出 HTML 格式的结果
print("<html>")
print("<head><title>锁小区结果</title></head>")
print("<body>")
print("<h1>锁小区结果</h1>")
print("<p>PCI: " .. PCI .. "</p>")
print("<p>频率: " .. FREQUENCY .. "</p>")
print("<p>" .. RESULT .. "</p>")
print("<p>锁小区成功</p>")
print("</body>")
print("</html>")
