#!/usr/bin/lua

-- 设置响应头
print("Content-type: text/html; charset=UTF-8\n")
print() -- 重要，必须有一个空行以结束头部

-- 解析查询字符串函数
local function parse_query(query)
    local params = {}
    for pair in string.gmatch(query, "([^&]+)") do
        local key, value = pair:match("([^=]*)=([^=]*)")
        if key and value then
            value = value:gsub("+", " "):gsub("%%(%x%x)", function(hex) return string.char(tonumber(hex, 16)) end)
            params[key] = value
        end
    end
    return params
end

-- 获取查询字符串
local query_string = os.getenv("QUERY_STRING") or ""

-- 解析查询字符串
local params = parse_query(query_string)

-- 提取参数并判断有效性，设置默认值
local frequency = params["frequency"] or "未提供"
local serialPort = params["serialPort"] or "未提供"
local PCI = params["PCI"] or "未提供"
local frequencyParam = params["Frequency"] or "未提供"
local devices = params["devices"] or "未提供"

-- 定义读取文件的函数
local function readFile(filePath)
    local file = io.open(filePath, "r")  -- 以只读模式打开文件
    if not file then
        return {}  -- 如果文件不存在，返回空表
    end

    local data = {}
    for line in file:lines() do
        table.insert(data, line)
    end
    file:close()  -- 关闭文件
    return data
end

-- 定义更新或添加配置的函数
local function updateConfig(data, key, value)
    local updated = false
    for i, line in ipairs(data) do
        if line:find(key .. ":") then
            data[i] = key .. ": " .. value  -- 替换已有的值
            updated = true
            break
        end
    end
    if not updated then
        table.insert(data, key .. ": " .. value)  -- 如果不存在，则添加新的配置
    end
end

-- 读取现有配置
local file_path = "/root/350/config_data.txt"
local existingData = readFile(file_path)

-- 更新配置
if frequency and frequency ~= "未提供" then
    updateConfig(existingData, "开机锁频", frequency)
end

if PCI and PCI ~= "未提供" then
    updateConfig(existingData, "开机锁小区", PCI)
end

if frequencyParam and frequencyParam ~= "未提供" then
    updateConfig(existingData, "频率", frequencyParam)
end

if serialPort and serialPort ~= "未提供" then
    updateConfig(existingData, "串口选择", serialPort)
end

if devices and devices ~= "未提供" then
    updateConfig(existingData, "物理接口", devices)
end

-- 保存更新后的配置到文件
local file = io.open(file_path, "w")  -- 以覆盖模式打开文件，以便写入新的配置
if file then
    for _, line in ipairs(existingData) do
        file:write(line .. "\n")
    end
    file:close()  -- 关闭文件
    print("配置已保存到文件: " .. file_path)
else
    print("<p>无法打开文件进行写入.</p>")
end

-- 输出 HTML 结果
print("<html>")
print("<head><title>配置结果</title></head>")
print("<body>")
print("<h1>提交的配置结果</h1>")
print("<p>开机锁频: " .. frequency .. "</p>")
print("<p>串口选择: " .. serialPort .. "</p>")
print("<p>开机锁小区: " .. PCI .. "</p>")
print("<p>频率: " .. frequencyParam .. "</p>")
print("<p>物理接口: " .. devices .. "</p>")
print("<p>配置已保存到文件: " .. file_path .. "</p>")

-- 输出全局变量内容
print("<h2>全局变量内容:</h2>")
for _, line in ipairs(existingData) do
    print("<p>" .. line .. "</p>")
end

print("</body>")
print("</html>")
