#!/bin/sh

#5G模块通讯接口
serial_device="/dev/ttyUSB0"
#ָAT输出日志 
output_file="/tmp/AT_output"
response="/tmp/response"
usb_info="/tmp/usb_info"
# 网络接口
interface_name="usbwan"
# 物理设备接口
usbmode='eth1'
# 文件路径
CONFIG_FILE="/root/350/config_data.txt"

# 读取 /root/350/config_data.txt 中的 ttyUSB 设备名
TTY_DEVICE=$(cat /root/350/config_data.txt | grep -Eo 'ttyUSB[0-9]+' | head -n 1)
# 提取开机锁频的值
LOCK_FREQUENCY=$(sed -n 's/开机锁频: \(.*\)/\1/p' "$CONFIG_FILE")

# 检查是否成功获取到设备名
if [ -z "$TTY_DEVICE" ]; then
    echo "未能从 config_data.txt 中获取 ttyUSB 设备名，请检查文件内容"
    exit 1
fi

# 输出获取到的 ttyUSB 设备名
echo "获取到的 ttyUSB 设备名: $TTY_DEVICE"
serial_device="/dev/$TTY_DEVICE"
echo "当前设备: "/dev/$TTY_DEVICE""
echo "开机锁频: $LOCK_FREQUENCY"

# 从 config_data.txt 中提取接口名
DEVICE=$(grep -Eo 'eth[0-9]+' /root/350/config_data.txt | head -n 1)
if [ -z "$DEVICE" ]; then
    DEVICE=$(grep -Eo 'USB[0-9]+' /root/350/config_data.txt | head -n 1)
fi
usbmode=$DEVICE
# 检查提取的接口名
if [ -z "$DEVICE" ]; then
    echo "未能从 config_data.txt 中获取到物理接口名，请检查文件内容"
    exit 1
else
    echo "获取到的接口名: $DEVICE"
	echo "获取到的接口名: $usbmode"
fi

parseIPAddress() {
    local data="$1"

    #    ˳"CGPADDR""CGCONTRDP"     
    ipArr=$(grep "+CGPADDR" "$data")
    dnsArr=$(grep "+CGCONTRDP:" "$data")

    local ip dnsone dnstwo gateway

    #   ȡIP  ַ      
    if [ -n "$ipArr" ]; then
        ip=$(echo "$ipArr" | cut -d',' -f2 | tr -d '"')
        gateway=$(echo "$ip" | awk -F. '{print $1"."$2"."$3".1"}' | tr -d '"')
    fi

    #   ȡDNS1  DNS2
    if [ -n "$dnsArr" ]; then
       # dnsone=$(echo "$dnsArr" | cut -d',' -f6 | tr -d '"')
       # dnstwo=$(echo "$dnsArr" | cut -d',' -f7 | tr -d '"')
        dnsone=$(echo "$dnsArr" | cut -d',' -f6   | tr -d '"')
        dnstwo=$(echo "$dnsArr" | cut -d',' -f7   | tr -d '"')

    fi

    #    ؽ        Ľ  
    echo "$ip" 
    echo "$gateway"
    echo "$dnsone"
    echo "$dnstwo"
    echo "$dnsone $dnstwo"

if [ -z "$ip" ]
   then
    echo "NG"
  else
    echo "OK"
    sleep 5

    echo "" > $output_file
	
	# 检查接口是否存在
    ifconfig | grep -q "$interface_name"

	if [ $? -ne 0 ]; then
		# 如果不存在，则创建接口
		uci set network.$interface_name=interface
		uci set network.$interface_name.proto=static
		uci set network.$interface_name.ifname=$usbmode  #物理设备接口
		uci set network.$interface_name.ipaddr=$ip  # 设置静态 IP 地址
		uci set network.$interface_name.netmask="255.255.255.0"  # 设置子网掩码
		uci set network.$interface_name.gateway=$gateway  # 设置网关
        uci set network.$interface_name.dns="$dnsone $dnstwo"  # 设置dns
		 # 设置防火墙为 wan 口
		 # 获取当前 wan 区的网络配置 
	     if uci show firewall | grep -q "network='.*$interface_name.*'"; then
           echo "接口 eth1 在防火墙列表中。"
         else
           echo "接口 eth1 不在防火墙列表中。"
		   uci add_list firewall.@zone[1].network="$interface_name"
         fi
		uci commit firewall
		uci commit network
		ifdown $interface_name && ifup $interface_name
		echo "创建接口 $interface_name 成功，并设置防火墙为 wan 口"
    else
	echo "接口 $interface_name 已存在"
	/sbin/uci set network.usbwam.ipaddr=$ip # 设置静态 IP 地址
    /sbin/uci set network.usbwam.gateway=$gateway # 设置网关
    /sbin/uci set network.usbwam.dns="$dnsone $dnstwo" # 设置dns
	/sbin/uci set network.$interface_name.netmask="255.255.255.0"  # 设置子网掩码 
    /sbin/uci commit
    ifdown $interface_name && ifup $interface_name
	fi

fi
  #  /sbin/uci set network.usbwam.ipaddr="10.5.36.118"
  #  /sbin/uci set network.usbwam.gateway="10.5.36.1"
  #  /sbin/uci commit
  #  /etc/init.d/network restart
 } 
 
get_devices(){

# 目标 PID
target_pid="7127"
# 获取 lsusb 信息并保存到临时文件
lsusb > /tmp/usb_info_tmp.txt

# 检查文件是否成功创建
if [ -f /tmp/usb_info_tmp.txt ]; then
    echo "lsusb 输出信息已保存到 /tmp/usb_info_tmp.txt 文件。"
    # 读取文件内容并处理
    found=false
    cat /tmp/usb_info_tmp.txt 
	target_string="sample"
	file_path="/tmp/usb_info_tmp.txt"

	if grep -q "$target_pid" "$file_path"; then
		echo "FM350挂载成功，准备拨号"
		echo 0e8d 7127 > /sys/bus/usb-serial/drivers/generic/new_id
		echo 0e8d 7126 > /sys/bus/usb-serial/drivers/generic/new_id
	else
		echo "FM350挂载不成功"
		exit 1
	fi	
    # 清理临时文件
    rm /tmp/usb_info_tmp.txt
fi

}

# ��ȡ�ͱ��洮�����ݵĺ���
read_serial() {
    echo -n "$(date "+%Y-%m-%d-%H:%M:%S")" >> "$output_file"
	#锁频部分
	#comgt -d $serial_device -s /root/LOCKNETWORK.gcom
	sleep 3
    comgt -d $serial_device -s /root/dialog.gcom > $output_file
    cat $output_file
    parseIPAddress "$output_file"
    cat_pid=$!
    sleep 2
    kill "$cat_pid"
}
check_com(){
	for device in /dev/ttyUSB* 
	do
		if [ -c "$device" ]; then
			# 尝试打开串口并发送一些数据，然后检查是否有响应
			echo -n '' > $response
			comgt -d "$device" -s /root/check.gcom > $response
			if grep -q "OK" $response; then
                 echo "串口 $device 可用。"
				 serial_device=$device
				 echo "当前串口 $serial_device"
			else
				echo "串口 $device 不可用。"
				
			fi
		fi
	done
}  
main() {
        echo "start"
		#get_devices
		#check_com
        #  ļ  ж ȡ   ݲ IP  Ϣ
		execute_script_based_on_lock_frequency $LOCK_FREQUENCY 
        read_serial         
        echo "done"
}
# 函数：根据锁频值执行相应的脚本
execute_script_based_on_lock_frequency() {
    local LOCK_FREQUENCY="$1"

    case "$LOCK_FREQUENCY" in
        "CLOSE")
            echo "执行 close 脚本"
            # ./close_script.sh  # 取消注释来执行
            ;;
		"NOCELL")
            echo "执行 NOCELL 脚本"
            # ./close_script.sh  # 取消注释来执行
			exit 1
            ;;
        "AUTO")
            echo "执行 auto 脚本"
            # ./auto_script.sh  # 取消注释来执行
			comgt -d $serial_device -s /root/LOCKNETWORK.gcom
            ;;
	    "N78")
            echo "执行 N78 脚本"
            # ./N1_script.sh  # 取消注释来执行
			chat -t 3 -e '' 'AT+GTACT=14,6,6,5078' OK >> $serial_device < $serial_device
            ;;
		"N28")
            echo "执行 N28 脚本"
			chat -t 3 -e '' 'AT+GTACT=14,6,6,5028' OK >> $serial_device < $serial_device
            # ./N1_script.sh  # 取消注释来执行
            ;;
        "N41")
            echo "执行 N41 脚本"
			chat -t 3 -e '' 'AT+GTACT=14,6,6,5041' OK >> $serial_device < $serial_device
            # ./N41_script.sh  # 取消注释来执行
            ;;
        "N1")
            echo "执行 N1 脚本"
			chat -t 3 -e '' 'AT+GTACT=14,6,6,501' OK >> $serial_device < $serial_device
            # ./N1_script.sh  # 取消注释来执行
            ;;
        *)
            echo "未知的锁频值: $LOCK_FREQUENCY"
            ;;
    esac
}


main