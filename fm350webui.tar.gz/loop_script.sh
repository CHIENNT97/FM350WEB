#!/bin/sh
# 循环执行的命令

# 读取 /root/350/config_data.txt 中的 ttyUSB 设备名
TTY_DEVICE=$(cat /root/350/config_data.txt | grep -Eo 'ttyUSB[0-9]+' | head -n 1)

# 检查是否成功获取到设备名
if [ -z "$TTY_DEVICE" ]; then
    echo "未能从 config_data.txt 中获取 ttyUSB 设备名，请检查文件内容"
    exit 1
fi

# 输出获取到的 ttyUSB 设备名
echo "获取到的 ttyUSB 设备名: $TTY_DEVICE"
echo "当前设备: "/dev/$TTY_DEVICE""


# 循环执行的命令
while true; do
    # 执行命令
    comgt -d "/dev/$TTY_DEVICE" -s /www/350/comgt/getdata.gcom > /tmp/data.txt
    
    # 执行网络检查脚本
    /root/net_check.sh 

    # 每次执行后等待 10 秒
    sleep 10
done

